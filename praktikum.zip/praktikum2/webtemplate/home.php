<?php
include_once 'atas.php' ;
?>

<h1>Welcome Home !!! </h1>

<?php
include_once 'bawah.php' ;
?>